package com.corejava.trainee;

public class TraineeNotFoundException extends Exception {
	private String errorMsg = "ID not found";

	public TraineeNotFoundException(String errorMsg) {
		super();
		this.errorMsg = errorMsg;
	}

	public TraineeNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String getMessage() {
		return this.errorMsg;
	}
	
}
