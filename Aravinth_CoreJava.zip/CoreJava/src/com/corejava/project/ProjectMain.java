package com.corejava.project;

public class ProjectMain {

	public static void main(String[] args) {
		Project myProject = new Project(1111,"Bank Application","Gopi",23);
		Project myProject1 = new Project();
		System.out.println(myProject.toString());
		System.out.println(myProject1.toString());
	}
}
