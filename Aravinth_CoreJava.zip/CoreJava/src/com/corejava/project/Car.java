package com.corejava.project;

public class Car {
	String color = "Pink";
	String type = "BMW";
	
	void start(){
		System.out.println("Car is Started!...");
	}
	
	void printDescription(){
		System.out.println("This is a " + color +" " + type);
	}
	
	Car(String c, String t){
		color = c;
		type = t;
	}
	
	Car(){}
	
	public static void main(String[] args){
		Car myCar = new Car();
		myCar.color = "White";
		myCar.type= "SUMO";
		myCar.start();
		myCar.printDescription();
		
		Car myCar1 = new Car ("Black","HONDA CITY");
		myCar1.printDescription();
		
		Car myCar2 = new Car();
		myCar2.printDescription();
	}
}
