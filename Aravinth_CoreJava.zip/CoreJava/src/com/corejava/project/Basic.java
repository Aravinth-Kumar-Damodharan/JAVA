package com.corejava.project;

public class Basic {
	public static void main(String[]args){
	int a =10;
	int b = 20;
	int c,d,e,f,g,h,i;
	char character = 'h';
	byte age = 30;
	long viewCount = 1121233354323332L;
	double decimal = 3.5677;
	float pi = 3.14F;
	c = a+b;
	d = b-a;
	e = a*b;
	f = b/a;
	h = ++a;
	g = a++;
	int temp = 10;
	boolean goodSalary = true;
	boolean goodCredit = true;
	boolean noCriminalRecord = false;
	int k = 0;
	String role = "admin";
	System.out.println("char is : " +character);
	System.out.println("Age is : " +age);
	System.out.println("View Count is : " +viewCount);
	System.out.println("Float pi value is : " +pi);
	System.out.println("Double decimal value is : " +decimal);
	System.out.println("Addition of two number is : "+c);
	System.out.println("Substraction of two number is : "+d);
	System.out.println("Multiplication of two number is : "+e);
	System.out.println("Division of two number is : "+f);
	System.out.println("Pre-increment is : ");
	System.out.println(++b);
	System.out.println("Post-increment is : ");
	System.out.println(a++);
	if (a>0){
		System.out.println("Positive number");
	}
	else{
		System.out.println("Negative number");
	}
	if(temp>40){
		System.out.println("HOT DAY");
	}
	else if(temp >= 15 && temp<= 40){
		System.out.println("MODERATE DAY");
	}
	else{
		System.out.println("Cold Day");
	}
	if((goodSalary && goodCredit)&& !(noCriminalRecord)){
		System.out.println("ELIGIBLE FOR LOAN");
	}
	else{
		System.out.println("Not ELIGIBLE FOR LOAN");
	}
	switch(role){
		case  "Programmer":
		System.out.println("YOU ARE AN Programmer");
		break;
		case  "admin":
		System.out.println("YOU ARE AN ADMIN");
		break;
	}
	
	for(int j = 0; j<=5; j++){
		
		System.out.println(k++);
	}
	}
}
