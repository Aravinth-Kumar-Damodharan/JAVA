package com.corejava.project;

public class Car1 {
	String color;
	String type;
	int serialNumber;
	static int carCount;
	
	static {
		//carCount = 3; 
		setCarCount(3);
	}
	
	public static void setCarCount(int c){
		carCount = c;
	}
	
	Car1(){
		carCount++;
		serialNumber = carCount;
	}
	
	{
		color = "red";
		type = "Celica";
	}
	
	Car1(String color, String type){
		this();
		this.color = color;
		this.type = type;
	}
	
	String getDescription(){
		String desc = "This is a " + color +" "+type;
		return desc;
	}
	
	void customize(String color, String type){
		this.color = color;
		this.type = type +" "+this.type;
		System.out.println(getDescription());
	}
	
	public static void main(String[] args) {
		Car1 myCar = new Car1();
		myCar.customize("blue", "convertible");
		
		}

}
