package com.corejava.bankaccount;

import java.util.Arrays;

public class Bank {
	private BankAccount[] bankAccount;

	public BankAccount[] getBankAccount() {
		return bankAccount;
	}

	public void setBankAccount(BankAccount[] bankAccount) {
		this.bankAccount = bankAccount;
	}

	public Bank(BankAccount[] bankAccount) {
		super();
		this.bankAccount = bankAccount;
	}

	public Bank() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Bank [bankAccount=" + Arrays.toString(bankAccount) + "]";
	}

	public  BankAccount[] checkAccount(String accountNo){
		BankAccount[] foundAccounts = new BankAccount[2];
		for(BankAccount bankAccount : bankAccount ){
			if(bankAccount.getAccountNo().equals(accountNo)){
				int i = 0;
				foundAccounts[i] = bankAccount;
				i++;
			}
			else{
				foundAccounts = null;
			}
		}
		return foundAccounts;
	}
	
	
	
//	public BankAccount[] getBalance(String accountNo){
//		BankAccount[] foundAccounts = new BankAccount[2];
//		for(BankAccount bankAccount : bankAccount){
//			
//		}
//	}
}
