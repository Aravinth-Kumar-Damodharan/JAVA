package com.corejava.bankaccount;

public class BankAccountMain {

	

	public static void main(String[] args) {
		BankAccount[] bankAccount = new BankAccount[3];
		BankAccount account1 = new BankAccount("12345677","Aravinth Kumar");
		BankAccount account2 = new BankAccount("3124324","Arjun",2300);
		
		System.out.println(account1.toString());
		System.out.println(account2.toString());
		
		Bank bank = new Bank(bankAccount);
		
		System.out.println(bank.checkAccount("12345677").toString());
		System.out.println(bank.checkAccount("3123324").toString());
	}

}
