package com.css.productcomparator.dto;
import java.util.Comparator;

public class Product implements Comparator<Product> {
	private String productName;
	private int price;
	private int productId;
	private int quantityOnHand;
	private int reorderLevel;
	private int reorderQty;
	
	public int compare(Product p1, Product p2){
		return p1.getPrice()-p2.getPrice();
	}

	public Product(String productName, int price, int productId, int quantityOnHand, int reorderLevel, int reorderQty) {
		super();
		this.productName = productName;
		this.price = price;
		this.productId = productId;
		this.quantityOnHand = quantityOnHand;
		this.reorderLevel = reorderLevel;
		this.reorderQty = reorderQty;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public int getQuantityOnHand() {
		return quantityOnHand;
	}

	public void setQuantityOnHand(int quantityOnHand) {
		this.quantityOnHand = quantityOnHand;
	}

	public int getReorderLevel() {
		return reorderLevel;
	}

	public void setReorderLevel(int reorderLevel) {
		this.reorderLevel = reorderLevel;
	}

	public int getReorderQty() {
		return reorderQty;
	}

	public void setReorderQty(int reorderQty) {
		this.reorderQty = reorderQty;
	}
	
	
}
