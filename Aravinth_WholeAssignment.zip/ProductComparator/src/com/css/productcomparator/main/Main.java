package com.css.productcomparator.main;
import java.util.ArrayList;
import java.util.Collections;

import com.css.productcomparator.dto.PriceCompare;
import com.css.productcomparator.dto.Product;

public class Main {
	public static void main(String[] args) {
		ArrayList<Product> list = new ArrayList<Product>();

		list.add(new Product("Toy", 250, 111,20,10,50));
		list.add(new Product("Pen", 50, 222,47,10,50));
		list.add(new Product("Note", 60, 333,50,10,50));

		System.out.println("SORTING BY PRODUCT PRICE :");
		PriceCompare priceCompare = new PriceCompare();

		Collections.sort(list, priceCompare);
		for (Product product : list)
			System.out.println(product.getPrice() + " " + product.getProductName() + " " + product.getProductId() + " " + product.getQuantityOnHand() + " " + product.getReorderLevel() + " " + product.getReorderQty());

	}
}
