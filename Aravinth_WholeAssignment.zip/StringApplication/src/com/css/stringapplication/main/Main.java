package com.css.stringapplication.main;

import com.css.stringapplication.dto.StringServiceProvider;

public class Main {

	public static void main(String[] args) {
		StringServiceProvider string = new StringServiceProvider();
		
		//Reversing the String
		String rev = string.StrRev("Aravinth");
		System.out.println(rev);
		
		//Linear Search
		string.linearSearch("Aravinth", 'v');
		
		//Replace element
		String str = "Aravinth";
		char element = 'a';
		char replacement = 'A';
		
		String replace = string.replace(str, element, replacement);
		System.out.println(replace);
		
		

	}

}
