package com.css.productstoresapplication.dto;

public class Product {
	
public int productID;
 public String productName;
 public double price;
 public int quantityOnHand;
 public int reorderLevel;
 public int reorderQty;
public int getProductID() {
	return productID;
}
public void setProductID(int productID) {
	this.productID = productID;
}
public String getProductName() {
	return productName;
}
public void setProductName(String productName) {
	this.productName = productName;
}
public double getPrice() {
	return price;
}
public void setPrice(double price) {
	this.price = price;
}
public int getQuantityOnHand() {
	return quantityOnHand;
}
public void setQuantityOnHand(int quantityOnHand) {
	this.quantityOnHand = quantityOnHand;
}
public int getReorderLevel() {
	return reorderLevel;
}
public void setReorderLevel(int reorderLevel) {
	this.reorderLevel = reorderLevel;
}
public int getReorderQty() {
	return reorderQty;
}
public void setReorderQty(int reorderQty) {
	this.reorderQty = reorderQty;
}
public Product(int productID, String productName, double price, int quantityOnHand, int reorderLevel, int reorderQty) {
	super();
	this.productID = productID;
	this.productName = productName;
	this.price = price;
	this.quantityOnHand = quantityOnHand;
	this.reorderLevel = reorderLevel;
	this.reorderQty = reorderQty;
}
public Product() {
	super();
	// TODO Auto-generated constructor stub
}
@Override
public String toString() {
	return "Product [productID=" + productID + ", productName=" + productName + ", price=" + price + ", quantityOnHand="
			+ quantityOnHand + ", reorderLevel=" + reorderLevel + ", reorderQty=" + reorderQty + "]";
}


 
}

