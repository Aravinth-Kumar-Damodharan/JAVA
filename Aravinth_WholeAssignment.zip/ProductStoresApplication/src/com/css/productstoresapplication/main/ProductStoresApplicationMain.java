package com.css.productstoresapplication.main;

import java.util.Arrays;

import com.css.productstoresapplication.dto.Product;
import com.css.productstoresapplication.dto.Stores;
import com.css.productstoresapplication.exception.ProductNotFoundException;

public class ProductStoresApplicationMain {

	public static void main(String[] args) {
		Product[] products=new Product[3];
		products[0]=new Product(111,"Toy",120.00,100,10,50);
		products[1]=new Product(222,"Pen",20.00,20,10,50);
		products[2]=new Product(333,"Notes",50.00,10,10,50);
		Stores str=new Stores(products);
		double billValue = 0;
		try {
			billValue = str.sellItem(123,5);
		} catch (ProductNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		boolean arrived = false;
		try {
			arrived = str.updateStock(125,10);
		} catch (ProductNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println("BillValue:" +billValue);
		System.out.println("ArrivedQty:"+arrived);
		System.out.println(Arrays.deepToString(str.getProducts()));

	}

}
