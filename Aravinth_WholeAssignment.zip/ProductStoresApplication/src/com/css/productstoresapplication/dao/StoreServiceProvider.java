package com.css.productstoresapplication.dao;

import com.css.productstoresapplication.exception.ProductNotFoundException;

public interface StoreServiceProvider {
	public double sellItem(int productCode,int qtyRequired) throws ProductNotFoundException;
	public boolean updateStock(int productCode,int arrivedQty) throws ProductNotFoundException;
}
