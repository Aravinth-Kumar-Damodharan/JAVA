package com.css.bankapplication.main;

import com.css.bankapplication.dto.Bank;
import com.css.bankapplication.dto.BankAccount;
import com.css.bankapplication.exception.InsufficientFundException;
import com.css.bankapplication.exception.InvalidAccountException;

public class Main {

	public static void main(String[] args){
		BankAccount[] accounts = new BankAccount[3];
		accounts[0] = new BankAccount("Aravinth");
		accounts[1] = new BankAccount("Akash");
		accounts[2] = new BankAccount("Arjun");
		
		Bank sbiBank = new Bank("SBI123","Arakkonam",accounts);
		BankAccount foundAccount = null;
		double balance = 0.0;
		try {
			foundAccount = sbiBank.checkAccount("1001");
		} catch (InvalidAccountException e) {
			e.printStackTrace();
		}
		
		try {
			balance = sbiBank.getBalance("1001");
		} catch (InvalidAccountException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			sbiBank.depositMoney("1000", 100000.00);
		} catch (InsufficientFundException | InvalidAccountException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			sbiBank.withdrawMoney("1001", 100);
		} catch (InsufficientFundException | InvalidAccountException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			sbiBank.transferMoney("1000", "1002", 500);
		} catch (InsufficientFundException | InvalidAccountException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(foundAccount.toString());
		
		System.out.println(balance);
	
			
		try {
			System.out.println(sbiBank.getBalance("1000"));
		} catch (InvalidAccountException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		try {
			System.out.println(sbiBank.getBalance("1001"));
		} catch (InvalidAccountException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		try {
			System.out.println(sbiBank.getBalance("1000"));
		} catch (InvalidAccountException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		try {
			System.out.println(sbiBank.getBalance("1002"));
		} catch (InvalidAccountException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
	}

}

