package com.css.traineeapplication.main;

import java.util.Arrays;

import com.css.traineeapplication.dto.Batch;
import com.css.traineeapplication.dto.Trainee;
import com.css.traineeapplication.exception.TraineeNotFoundException;

public class TraineeBatchMain {
	public static void main(String[] args)  {
		Trainee[] trainees = new Trainee[3];
		trainees[0] = new Trainee(124,"Aravinth","8939219808","aravinth97@gmail.com","Male",23);
		trainees[1] = new Trainee(123,"Deepika","8756983412","deepika97@gmail.com","Female",25);
		trainees[2] = new Trainee(125,"Deepika","8756983412","deepika97@gmail.com","Female",25);
		Batch batch = new Batch(10,"21 Jan", "22 Feb",trainees);
		
			try {
	 
				System.out.println(Arrays.deepToString(batch.getTrainees(123)));
				System.out.println(Arrays.deepToString(batch.getTrainees("Male")));
			} catch (TraineeNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
	}
}
}
