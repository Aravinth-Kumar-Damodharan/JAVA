package com.css.companyapplication.main;
import java.util.HashMap;
import java.util.Map;

public class CompanyApplicationMain {
	public static void main(String[] args) {
			Map<Integer,String> employees=new HashMap<>();
			employees.put(1000, "Arjun");
			employees.put(1001, "Aravinth");
			employees.put(1002, "Sam");

			
			System.out.println(employees.get(1001));
		}
}


