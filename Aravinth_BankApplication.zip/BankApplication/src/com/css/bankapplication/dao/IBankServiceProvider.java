package com.css.bankapplication.dao;

import com.css.bankapplication.dto.BankAccount;
import com.css.bankapplication.exception.InsufficientFundException;
import com.css.bankapplication.exception.InvalidAccountException;

public interface IBankServiceProvider {
	public BankAccount checkAccount(String accountNo) throws InvalidAccountException;
	public double getBalance(String accountNo) throws InvalidAccountException;
	public boolean depositMoney(String accountNo, double amount) throws InvalidAccountException, InsufficientFundException;
	public boolean withdrawMoney(String accountNo, double amount) throws InvalidAccountException, InsufficientFundException;
	public boolean transferMoney(String fromAccountNo, String toAccountNo, double amount) throws InsufficientFundException,InvalidAccountException;
}
